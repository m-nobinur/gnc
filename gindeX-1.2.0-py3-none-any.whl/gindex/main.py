#!/usr/bin/env python3
import csv
import itertools
import json
import os
import pathlib
import shutil
import string
import sys
import time
import httplib2
from typing import List, Tuple

from oauth2client.service_account import ServiceAccountCredentials
from halo import Halo
from tqdm import tqdm
import click

try:
    from gindex.utils.stats import _gbold, format_summary
except ModuleNotFoundError:
    from utils.stats import _gbold, format_summary


class SetupGindex:
    def __init__(self) -> None:
        self.SCOPES = ["https://www.googleapis.com/auth/indexing"]
        self.ENDPOINT = (
            "https://indexing.googleapis.com/v3/urlNotifications:publish"
        )

    def __ask_to_update(self) -> str:
        update_or_not = click.prompt(
            click.style(
                "Do you want to update the URLs(csv) file? (y/n)",
                bold=True,
                fg="blue",
            ),
        )

        return update_or_not

    def __ask_update_start(self) -> str:
        click.clear()
        update_or_not = click.prompt(
            click.style(
                "Do you want to update the start index? (y/n)",
                bold=True,
                fg="blue",
            ),
        )

        return update_or_not

    def __get_clean_csv_from_input(self) -> str:
        click.clear()
        csv_file = click.prompt(
            click.style(
                "To update the URLs(csv) file, drag & drop the URLs(csv) file here",
                fg="magenta",
                bold=True,
            ),
        )

        return csv_file

    def __add_or_update_url_file(self, url_files: List[str]):
        if url_files:
            for url_file in url_files:
                os.remove(
                    os.path.abspath(
                        os.path.join("gindex", ".store", ".urls", url_file)
                    )
                )
            url_files = []

        csv_file = self.__get_clean_csv_from_input().strip(
            string.whitespace + "'\""
        )
        while not csv_file.endswith(".csv"):
            click.secho(
                click.style(
                    "URLs file must be in CSV format. Please provide a valid CSV file\n",
                    fg="red",
                    bold=True,
                )
            )
            csv_file = self.__get_clean_csv_from_input().strip(
                string.whitespace + "'\""
            )

        csv_absolute_path = pathlib.Path(csv_file.strip()).resolve()
        if csv_absolute_path.exists():
            shutil.copy(
                csv_absolute_path,
                os.path.abspath(os.path.join("gindex", ".store", ".urls")),
            )
            return csv_absolute_path.name
        else:
            raise FileExistsError(
                click.style(
                    "Failed copying URLs(csv) file. Please make sure the file is valid and try again.\n",
                    fg="red",
                    bold=True,
                )
            )

    def __authenticate(self, auth_file: str) -> httplib2.Http:
        with Halo(
            text="Authenticating with Indexing API...",
            spinner="dots",
            color="magenta",
            text_color="green",
        ) as spinner:
            auth_file_path = os.path.abspath(
                os.path.join("gindex", ".store", ".services", auth_file)
            )
            credentials = ServiceAccountCredentials.from_json_keyfile_name(
                auth_file_path, scopes=self.SCOPES
            )

            http = credentials.authorize(httplib2.Http())
            time.sleep(1.25)
            spinner.text = "Authenticated."
            time.sleep(1.25)
        return http

    def _get_url_file(self) -> str:
        url_files = [
            file
            for file in os.listdir(
                os.path.abspath(os.path.join("gindex", ".store", ".urls"))
            )
            if file.endswith(".csv")
        ]
        update_res = self.__ask_to_update()

        if not update_res.lower() in ["y", "yes"]:
            if url_files:
                return url_files[0]
            else:
                click.secho(
                    "No URLs(csv) file found. Please update the file first.\n",
                    fg="red",
                    bold=True,
                )
            return self._get_url_file()
        else:
            return self.__add_or_update_url_file(url_files)

    def _get_start_index(self) -> int:
        update_res = self.__ask_update_start()
        start_file = os.path.abspath(
            os.path.join("gindex", ".store", "start.txt")
        )
        with open(start_file, "r") as f:
            start_index = f.read().strip()

        if update_res.lower() in ["y", "yes"]:
            click.clear()
            start_index = click.prompt(
                click.style("Enter the start index: ", fg="blue", bold=True)
            )

            if not start_index.isdigit():
                click.secho(
                    "Invalid start index. Please enter a valid number.\n",
                    fg="red",
                )
                return self._get_start_index()

            with open(start_file, "w") as f:
                f.write(start_index.strip())

            click.echo()

            return int(start_index)

        return int(start_index)

    def _read_urls_from_csv(
        self, file_path: str, start: int
    ) -> Tuple[List[List[str]], int]:
        click.clear()
        urls = []
        with open(file_path, "r") as csv_file:
            reader = csv.reader(csv_file)
            rows = list(reader)
            s = start - 1
            e = s + 1000
            urls = rows[s:e]
            total_remaining_urls = len(rows[s:])
        click.secho(
            f"📃 Read {len(urls)} URLs from {file_path}.\n",
            fg="cyan",
            italic=True,
        )

        return urls, total_remaining_urls

    def _get_service_acounts(self) -> List[str]:
        json_files = [
            file
            for file in os.listdir(
                os.path.abspath(os.path.join("gindex", ".store", ".services"))
            )
            if file.endswith(".json")
        ]
        if not json_files:
            json_files = []
            service_file = click.prompt(
                click.style(
                    "Drag and drop the service file(.json) here",
                    fg="magenta",
                    bold=True,
                )
            ).strip(string.whitespace + "'\"")
            service_file_path = pathlib.Path(service_file.strip()).resolve()

            if (
                service_file_path.is_file()
                and service_file_path.suffix == ".json"
                and service_file_path.exists()
            ):
                shutil.copy(
                    service_file_path,
                    os.path.abspath(
                        os.path.join("gindex", ".store", ".services")
                    ),
                )
                json_files.append(service_file_path.name)
                click.secho(
                    "\nIMPORTANT: Copy the following service account to your Search Console with owner's permission: \n",
                    fg="red",
                    bold=True,
                )

                with open(service_file_path, "r") as f:
                    client_email = json.load(f)["client_email"]

                click.secho(client_email, fg="green", italic=True)
                click.confirm("\nPress Enter to continue")
            else:
                click.secho(
                    "Your program has not configured properly. Try again!\n",
                    fg="yellow",
                    bold=True,
                )
                return self._get_service_acounts()

        return [json_files[-1]]

    def _lets_gindex(
        self,
        url_file: str,
        start_index: int,
        file_name: str,
        service_acounts: List[str],
    ) -> Tuple[int, int, List[str], int]:
        urls_to_index, total_remaining = self._read_urls_from_csv(
            url_file, start_index
        )

        total_bars = min(len(service_acounts) * 200, len(urls_to_index))
        if urls_to_index:
            click.clear()
            click.secho(
                f"Sending indexing request for {total_bars} URLs from “{file_name}” file, starting from index {start_index}.\n",
                fg="blue",
                italic=True,
            )
        s, e = 0, 200
        click.secho()
        with tqdm(
            total=total_bars,
            colour="blue",
            dynamic_ncols=True,
            unit="page",
            bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]",
        ) as pbar:
            total_errors, total_success = 0, 0
            error_urls = []
            for auth_file in service_acounts:
                http = self.__authenticate(auth_file)
                urls = urls_to_index[s:e]

                if not urls:
                    break

                for url in urls:
                    content = {}
                    content["url"] = url[-1].strip()
                    content["type"] = "URL_UPDATED"
                    json_content = json.dumps(content)

                    _, content = http.request(
                        self.ENDPOINT, method="POST", body=json_content
                    )

                    result = json.loads(content.decode())  # type: ignore

                    if "error" in result:
                        total_errors += 1
                        error_urls.append(url)
                    else:
                        total_success += 1
                        time.sleep(0.25)
                    pbar.update(1)
                    pbar.set_description(
                        f"Indexing [Success: {total_success}, Error: {total_errors}]"
                    )

                s, e = e, e + 200
            pbar.colour = "green"
            pbar.desc = "Indexing Completed"

            return total_success, total_errors, error_urls, total_remaining


def main():
    try:
        gindexer = SetupGindex()
        service_acounts = gindexer._get_service_acounts()
        url_file = gindexer._get_url_file()
        start_index = gindexer._get_start_index()
        url_file_path = os.path.abspath(
            os.path.join("gindex", ".store", ".urls", url_file)
        )

        succ, err, err_urls, remaining = gindexer._lets_gindex(
            url_file_path, start_index, url_file, service_acounts
        )

        click.secho(
            "The program has completed indexing successfully.\n",
            fg="green",
            bold=True,
        )

    except KeyboardInterrupt:
        click.secho("\nExiting...\n", fg="red", italic=True)
        sys.exit(0)
    except click.exceptions.Abort:
        click.secho("\nExiting...\n", fg="red", italic=True)
        sys.exit(0)

    return succ, err, remaining, err_urls


if __name__ == "__main__":
    start_time = time.time()
    succ, err, remaining, err_urls = main()
    time_taken = time.time() - start_time
    hour = int(time_taken // 3600)
    minute = int((time_taken % 3600) // 60)
    second = int((time_taken % 3600) % 60)
    click.clear()
    _gbold("✔️ Indexing process completed successfully.\n")
    with Halo(
        text="Generating Summary...",
        spinner="dots",
        color="cyan",
        text_color="magenta",
    ) as spinner:
        time.sleep(2)
    click.echo(format_summary(succ, err, remaining, hour, minute, second))

    err_urls = list(itertools.chain.from_iterable(err_urls))
    err_urls = "\n".join(err_urls)

    click.echo(f"\nError URLs: \n[\n{err_urls}\n]\n")
    click.secho(
        "Copy the above error urls and put them on a CSV file.", fg="yellow"
    )
    click.secho("Index these urls in the next step.\n\n", fg="yellow")
    click.secho(
        "If you face any issues, please let me know at [mohammadnobinur[at]gmail[dot]com]",
        fg="blue",
        italic=True,
    )
    click.secho("\n\nThanks for using gindeX!\n\n", fg="cyan", bold=True)
