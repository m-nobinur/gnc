import warnings
from typing import Set

import pandas as pd


class CrawlNonIndexedURLs:
    def __init__(self, coverage: str, output: str) -> None:
        self.COVERAGE_FILE = coverage
        self.OUTPUT_PATH = output

    def exec_request(self, coverage: str) -> Set[str]:
        warnings.simplefilter("ignore")

        try:
            unique_urls = set()
            df = pd.read_excel(coverage, sheet_name="Table", engine="openpyxl")

            urls = set(df["URL"].dropna().tolist()[1:])
            unique_urls.update(urls)

            return unique_urls
        except Exception as e:
            print("Please check if the file is in the correct format.")
            raise e

    def start_drill(self) -> None:
        unique_urls = self.exec_request(self.COVERAGE_FILE)
        df_output = pd.DataFrame(unique_urls, columns=[""])
        df_output.to_csv(self.OUTPUT_PATH, index=False, header=False)
