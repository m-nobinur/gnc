import csv
import os
from pathlib import Path
from typing import List, Set
from bs4 import BeautifulSoup


class CrawlUrlsFromSitemap:
    def __init__(
        self, sitemap: str, output_folder: str, output_file_name: str
    ) -> None:
        """
        Initializes the object with the given `sitemap` and `output` parameters.

        Parameters:
            sitemap (str): The path to the sitemap file.
            output_folder (str): The path to the output directory.
            output_file_name (str): The name of the output file.

        Returns:
            None
        """
        self.SITEMAP_SOURCE = sitemap
        self.OUTPUT_FOLDER = output_folder
        self.OUTPUT_FILE_NAME = output_file_name

    def _extract_urls_from_sitemap(self, sitemap_source: str) -> Set[str]:
        """
        Extracts URLs from a given sitemap file.

        Args:
            sitemap_source (str): The path to the sitemap file.

        Returns:
            Set[str]: A set of URLs extracted from the sitemap file.

        Raises:
            Exception: If an error occurs while extracting the URLs from the sitemap.
        """
        try:
            with open(sitemap_source, "rb") as file:
                sitemap_content = file.read()

            soup = BeautifulSoup(sitemap_content, "xml")

            urls = [
                url.text.strip()
                for url in soup.findAll("loc")
                if not url.text.endswith(".xml") and url.text is not None
            ]

            return set(urls)
        except Exception as e:
            raise e

    def _write_urls_to_csv(
        self, urls: List[str], output_folder: str, csv_file_name: str
    ) -> None:
        try:
            Path(output_folder).mkdir(parents=True, exist_ok=True)

            with open(
                os.path.join(output_folder, csv_file_name), "w", newline=""
            ) as csvfile:
                writer = csv.writer(csvfile)
                for url in urls:
                    writer.writerow([url.strip('"')])
        except Exception as e:
            raise e

    def exec_extraction(self) -> None:
        """
        Executes the extraction process.

        Args:
            None

        Returns:
            None
        """
        urls = self._extract_urls_from_sitemap(self.SITEMAP_SOURCE)
        self._write_urls_to_csv(
            urls, self.OUTPUT_FOLDER, self.OUTPUT_FILE_NAME
        )
