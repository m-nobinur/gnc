#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import time
import click
import winreg as reg
from halo import Halo


def add_to_path(directory):
    """
    Add the specified directory to the system PATH environment variable.
    """
    key_path = r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
    value_name = "Path"

    try:
        with reg.OpenKey(
            reg.HKEY_LOCAL_MACHINE,
            key_path,
            0,
            reg.KEY_READ | reg.KEY_SET_VALUE,
        ) as key:
            current_path, _ = reg.QueryValueEx(key, value_name)
            new_path = f"{current_path};{directory}"
            reg.SetValueEx(key, value_name, 0, reg.REG_EXPAND_SZ, new_path)
    except Exception as e:
        print(f"Error: {e}")


def copy_to_bin(source_file, bin_folder):
    """
    Copy the specified file to the bin folder.
    """
    shutil.copy(source_file, bin_folder)


def is_gindexer_in_path():
    """
    Check if gindexer is in the system's PATH.
    """
    return shutil.which("gindexer") is not None


def _action():
    click.clear()
    click.secho(
        "Running gindeX Installer...\n",
        fg="cyan",
        italic=True,
    )
    if os.path.basename(os.getcwd()) != "gindex":
        click.secho(
            "Please run this script from the gindex directory.",
            fg="yellow",
            bold=True,
        )
    else:
        with Halo(
            text="Setting up gindex...",
            spinner="dots",
            color="magenta",
            text_color="green",
        ) as spinner:
            dir_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gindex")

            if os.path.exists(
                os.path.expanduser("~/._gindexer")
            ) and os.path.isfile(os.path.expanduser("~/._gindexer")):
                try:
                    os.remove(str(os.path.expanduser("~/._gindexer")))
                except Exception:
                    subprocess.run(["del", "~/.gindexer"])

            if not os.path.isdir(os.path.expanduser("~/._gindexer")):
                os.makedirs(os.path.expanduser("~/._gindexer"))
            else:
                shutil.rmtree(os.path.expanduser("~/._gindexer"))
                os.makedirs(os.path.expanduser("~/._gindexer"))

            shutil.copytree(
                dir_path, os.path.expanduser("~/._gindexer/gindex")
            )

            os.chdir(os.path.expanduser("~/._gindexer/gindex"))

            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "venv",
                    ".gindex_venv",
                ],
                check=True,
                capture_output=True,
            )

            spinner.text = "Installing requirements (it may take a while)..."
            spinner.spinner = "dots12"
            spinner.color = "cyan"
            spinner.text_color = "blue"

            subprocess.run(
                [
                    os.path.join(".gindex_venv", "Scripts", "pip.exe"),
                    "install",
                    "-r",
                    "requirements.txt",
                ],
                check=True,
                capture_output=True,
            )

            spinner.text = "Installing script..."
            spinner.color = "green"
            time.sleep(1)

            gindex_folder = os.path.dirname(os.path.abspath(__file__))
            bin_folder = os.path.join(os.environ["ProgramFiles"], "gindexer")
            gindexer_bat = os.path.join(gindex_folder, "gindexer.bat")

            if not os.path.exists(bin_folder):
                os.makedirs(bin_folder)

            copy_to_bin(gindexer_bat, bin_folder)
            add_to_path(bin_folder)

            if is_gindexer_in_path():
                spinner.succeed("Setup complete.")
            else:
                spinner.fail("Setup failed. Run the setup program again.")
                sys.exit(1)

        click.echo("-" * 20)
        click.secho(
            f"\n\nRun {click.style('gindexer', fg='blue', bold=True)} to start using gindex.",
            fg="cyan",
            italic=True,
            bold=False,
        )
        click.echo(f"{'-' * 30}\n")


if __name__ == "__main__":
    _action()
