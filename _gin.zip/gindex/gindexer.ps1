Write-Host "Please wait, gindex is launching..."

$gindexPath = Join-Path $env:USERPROFILE "\._gindexer\gindex"

Set-Location -Path $gindexPath

$activateScript = Join-Path ".gindex_venv\Scripts" "activate"
if (Test-Path $activateScript) {
    & $activateScript

    python main.py


    & "$env:USERPROFILE\._gindexer\gindex\.gindex_venv\Scripts\deactivate"
}

