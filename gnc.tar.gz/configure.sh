#!/bin/bash
set -e
echo -ne "\033[1;34mRunning setup(this may take a while)...\033[0m\n"
chmod +x ./g_n_c;sleep 1.5
./g_n_c