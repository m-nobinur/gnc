#!/bin/bash

set -e
echo -ne "\033[1;34mRunning setup(this may take a while)...\033[0m\n";chmod +x ./_gnc;sleep 1.5;./_gnc;