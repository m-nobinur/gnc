import json
import csv
import os
import pathlib
import platform
import subprocess
import sys
import time
from oauth2client.service_account import ServiceAccountCredentials
import httplib2
from typing import List, Tuple


parent_dir = pathlib.Path(__file__).resolve().parent


class SetupGindexer:
    def __init__(self):
        self.SCOPES = ["https://www.googleapis.com/auth/indexing"]
        self.ENDPOINT = (
            "https://indexing.googleapis.com/v3/urlNotifications:publish"
        )

    def __ask_to_update_service_file(self) -> str:
        return input(
            "Need updating your service account(API KEY) file? (y/n): "
        )

    def __add_or_update_service_file(self, service_files: List[str]):
        if service_files:
            for service_file in service_files:
                os.remove(
                    os.path.abspath(
                        os.path.join(
                            parent_dir, ".store", "services", service_file
                        )
                    )
                )
            service_files = []

        print("\nThe 'services' folder has been opened.")
        print(
            "Please drop your service account file on this 'services' folder.\n"  # noqa
        )
        apis_path = os.path.abspath(
            os.path.join(parent_dir, ".store", "services")
        )

        if not os.path.exists(apis_path):
            os.makedirs(apis_path)

        system_platform = platform.system()
        try:
            if system_platform == "Windows":
                os.startfile(apis_path)
            elif system_platform == "Darwin":
                subprocess.Popen(["open", apis_path])
            elif system_platform == "Linux":
                subprocess.Popen(["xdg-open", apis_path])
        except Exception as e:
            print("Unable to open the services folder.")
            print(f"Exception: {e}")
        print("If the file explorer does not open automatically,")
        print(
            "Click on the the file explorer and type 'n' in the following prompt.\n"  # noqa
        )

        return input("Have you updated the URL file? (y/n): ")

    def __get_service_acounts(self) -> List[str]:
        json_files = [
            file
            for file in os.listdir(
                os.path.abspath(os.path.join(parent_dir, ".store", "services"))
            )
            if file.endswith(".json")
        ]
        if not json_files:
            print("*" * 40)
            print("\nERROR: No service account(API KEY) found.\n")
            print(
                "Following are the steps to add your service account(API KEY) file:"  # noqa
            )
            print(
                "1. Add your service account(API KEY) file by updating the file when prompted. Type 'y' to add it."  # noqa
            )
            print(
                "2. Make sure you have added the service mail to your search console with owner's permission."  # noqa
            )
            print("3. Finally, continue or run the process again. \n")
            print("*" * 40, "\n")

            user_res = self.__ask_to_update_service_file().strip()
            if user_res.lower() in ["y", "yes"]:
                file_updated = self.__add_or_update_service_file(json_files)
                if file_updated.lower() in ["y", "yes"]:
                    json_files = [
                        file
                        for file in os.listdir(
                            os.path.abspath(
                                os.path.join(parent_dir, ".store", "services")
                            )
                        )
                        if file.endswith(".json")
                    ]
            else:
                print("\nERROR: No service account(API KEY) found.")
                print("You are force exiting the program.\n")
                print(
                    "Restart the process again and add your service account(API KEY) file to complete the setup.\n"  # noqa
                )
                sys.exit(0)
        return json_files[:1]

    def __ask_to_update(self) -> str:
        return input("Do you want to update the URL file? (y/n): ")

    def __add_or_update_url_file(self, url_files: List[str]):
        if url_files:
            for url_file in url_files:
                os.remove(
                    os.path.abspath(
                        os.path.join(parent_dir, ".store", "urls", url_file)
                    )
                )
            url_files = []

        print("\nThe 'urls' folder has been opened.")
        print("Please drop your URLs(csv) file on this 'urls' folder.\n")
        urls_path = os.path.abspath(os.path.join(parent_dir, ".store", "urls"))

        if not os.path.exists(urls_path):
            os.makedirs(urls_path)

        system_platform = platform.system()
        try:
            if system_platform == "Windows":
                os.startfile(urls_path)
            elif system_platform == "Darwin":
                subprocess.Popen(["open", urls_path])
            elif system_platform == "Linux":
                subprocess.Popen(["xdg-open", urls_path])
        except Exception as e:
            print("Unable to open the urls folder.")
            print(f"Exception: {e}")
        print("If the file explorer does not open automatically,")
        print(
            "Click on the the file explorer and type 'n' in the following prompt.\n"  # noqa
        )

        return input("Have you updated the URL file? (y/n): ")

    def __get_url_files(self) -> List[str]:
        url_files = [
            file
            for file in os.listdir(
                os.path.abspath(os.path.join(parent_dir, ".store", "urls"))
            )
            if file.endswith(".csv")
        ]
        return url_files

    def _get_url_file(self) -> str:
        url_files = self.__get_url_files()
        update_res = self.__ask_to_update()

        if not update_res.lower() in ["y", "yes"]:
            if url_files:
                return url_files[0]
            else:
                print(
                    "No URL(csv) file found. Please update the file first.\n"
                )
            return self._get_url_file()
        else:
            user_res = self.__add_or_update_url_file(url_files)
            url_files = self.__get_url_files()
            if not user_res.lower() in ["y", "yes"]:
                if not url_files:
                    print(
                        "No URL(csv) file found. Please update the file first.\n"  # noqa
                    )
                    return self._get_url_file()
                return url_files[0]
            else:
                if url_files:
                    return url_files[0]
                else:
                    print(
                        "No URL(csv) file found. Please update the file first.\n"  # noqa
                    )
                    return self._get_url_file()

    def _read_urls_from_csv(
        self, file_path: str, start: int
    ) -> Tuple[List[List[str]], int]:
        urls = []
        with open(file_path, "r") as csv_file:
            reader = csv.reader(csv_file)
            rows = list(reader)
            s = start - 1
            e = s + 1000
            urls = rows[s:e]
            total_remaining_urls = len(rows[s:])
        print(f"Read {len(urls)} URLs from {file_path}.\n")

        return urls, total_remaining_urls

    def __authenticate(self, auth_file: str) -> httplib2.Http:
        auth_file_path = os.path.abspath(
            os.path.join(parent_dir, ".store", "services", auth_file)
        )
        credentials = ServiceAccountCredentials.from_json_keyfile_name(
            auth_file_path, scopes=self.SCOPES
        )

        http = credentials.authorize(httplib2.Http())
        time.sleep(1.25)
        return http

    def _lets_gindex(self) -> Tuple[int, int, List[str], int]:
        service_acounts = self.__get_service_acounts()

        url_file = self._get_url_file()
        start_index = 2
        url_file_path = os.path.abspath(
            os.path.join(parent_dir, ".store", "urls", url_file)
        )
        urls_to_index, total_remaining = self._read_urls_from_csv(
            url_file_path, start_index
        )

        total = min(len(service_acounts) * 200, len(urls_to_index))
        if urls_to_index:
            print(
                f"Sending indexing request for {total} URLs from “{url_file}” file, starting from index {start_index}.\n"  # noqa
            )
        s, e = 0, 200

        total_errors, total_success = 0, 0
        error_urls = []
        for auth_file in service_acounts:
            http = self.__authenticate(auth_file)
            urls = urls_to_index[s:e]

            if not urls:
                print("No more URLs to index.\n")
                break

            for url in urls:
                print("Submitting url...")
                content = {}
                content["url"] = url[0].strip()
                content["type"] = "URL_UPDATED"
                json_content = json.dumps(content)

                _, content = http.request(
                    self.ENDPOINT, method="POST", body=json_content
                )

                result = json.loads(content.decode())  # type: ignore

                if "error" in result:
                    total_errors += 1
                    error_urls.append(url)
                    print(result)
                else:
                    total_success += 1
                    print(
                        "URL: {}".format(
                            result["urlNotificationMetadata"]["url"]
                        )
                    )
                    print("Successfully submitted for indexing.\n")

                    time.sleep(0.25)

            s, e = e, e + 200
        print("Indexing Completed")

        return total_success, total_errors, error_urls, total_remaining


def main():
    try:
        gindexer = SetupGindexer()

        succ, err, err_urls, remaining = gindexer._lets_gindex()

        print("The program has completed indexing successfully.\n")

    except KeyboardInterrupt:
        print("\nExiting...\n")
        sys.exit(0)
    except Exception:
        print("\nExiting...\n")
        sys.exit(0)

    return succ, err, remaining, err_urls


def format_summary(succ, err, remaining, hour, minute, second):
    print(f"Total URLs indexed: {succ}")
    print(f"Total URLs failed: {err}")
    print(f"Total URLs remaining: {remaining}")
    print(f"Total time taken: {hour}h {minute}m {second}s")


if __name__ == "__main__":
    start_time = time.time()
    succ, err, remaining, err_urls = main()
    time_taken = time.time() - start_time
    hour = int(time_taken // 3600)
    minute = int((time_taken % 3600) // 60)
    second = int((time_taken % 3600) % 60)
    print("✔️ Indexing process completed successfully.\n")
    print(format_summary(succ, err, remaining, hour, minute, second))

    print(
        "\n\nIf you face any issues, please let me know at [mohammadnobinur[at]gmail[dot]com]"  # noqa
    )
    print("\n\nThanks for using gindeX!\n\n")
