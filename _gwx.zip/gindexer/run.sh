#!/bin/bash

printf "Please wait, gindex is launching...\n"
cd ~/.gindexer/gindexer
source .genv/bin/activate
sudo .genv/bin/python3 main.py
deactivate