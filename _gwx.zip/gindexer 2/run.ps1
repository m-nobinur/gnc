Set-ExecutionPolicy Bypass -Scope Process -Force;

cd "$env:USERPROFILE\.gindexer\gindexer";

.\genv\Scripts\Activate.ps1;

python main.py