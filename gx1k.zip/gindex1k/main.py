#!/usr/bin/env python3
import csv
import json
import os
import pathlib
import platform
import shutil
import string
import subprocess
import sys
import time
from datetime import datetime
import httplib2
from typing import List, Tuple

from oauth2client.service_account import ServiceAccountCredentials
from halo import Halo
from tqdm import tqdm
import click

try:
    from gindex1k.utils.stats import _gbold, format_summary
except ModuleNotFoundError:
    from utils.stats import _gbold, format_summary

parent_dir = pathlib.Path(__file__).resolve().parent


class SetupGindex:
    def __init__(self) -> None:
        self.SCOPES = ["https://www.googleapis.com/auth/indexing"]
        self.ENDPOINT = (
            "https://indexing.googleapis.com/v3/urlNotifications:publish"
        )

    def __ask_to_update(self) -> str:
        click.clear()
        update_or_not = click.prompt(
            click.style(
                "\nDo you want to update the URL(csv) file? (y/n)",
                bold=True,
                fg="blue",
            ),
        )

        return update_or_not

    def __ask_update_start(self) -> str:
        click.clear()
        update_or_not = click.prompt(
            click.style(
                "Do you want to update the start index? (y/n)",
                bold=True,
                fg="blue",
            ),
        )

        return update_or_not

    def __add_or_update_url_file(self, url_files: List[str]):
        if url_files:
            for url_file in url_files:
                os.remove(
                    os.path.abspath(
                        os.path.join(parent_dir, ".store", ".urls", url_file)
                    )
                )
            url_files = []

        click.secho(
            "\nThe 'urls' folder has been opened.", fg="cyan", italic=True
        )
        click.secho(
            "Please drop your URLs(csv) file on this 'urls' folder.\n",
            fg="cyan",
            italic=True,
        )
        urls_path = os.path.abspath(
            os.path.join(parent_dir, ".store", ".urls")
        )

        if not os.path.exists(urls_path):
            os.makedirs(urls_path)

        system_platform = platform.system()
        try:
            if system_platform == "Windows":
                os.startfile(urls_path)
            elif system_platform == "Darwin":
                subprocess.Popen(["open", urls_path])
            elif system_platform == "Linux":
                subprocess.Popen(["xdg-open", urls_path])
        except Exception as e:
            click.secho("Unable to open the urls folder.", fg="red", bold=True)
            click.echo(f"Exception: {e}")
        click.secho(
            "If the file explorer does not open automatically,",
            fg="yellow",
            italic=True,
        )
        click.secho(
            "Click on the the file explorer and type 'n' in the following prompt.\n",  # noqa
            fg="yellow",
            italic=True,
        )

        return click.prompt(
            click.style(
                "Have you updated the URL file? (y/n)",
                bold=True,
                fg="green",
            ),
        )

    def __authenticate(self, auth_file: str) -> httplib2.Http:
        with Halo(
            text="Authenticating with Indexing API...",
            spinner="dots",
            color="magenta",
            text_color="green",
        ) as spinner:
            auth_file_path = os.path.abspath(
                os.path.join(parent_dir, ".store", ".services", auth_file)
            )
            credentials = ServiceAccountCredentials.from_json_keyfile_name(
                auth_file_path, scopes=self.SCOPES
            )

            http = credentials.authorize(httplib2.Http())
            time.sleep(1.25)
            spinner.text = "Authenticated."
            time.sleep(1.25)
        return http

    def __get_url_files(self) -> List[str]:
        url_files = [
            file
            for file in os.listdir(
                os.path.abspath(os.path.join(parent_dir, ".store", ".urls"))
            )
            if file.endswith(".csv")
        ]
        return url_files

    def _get_url_file(self) -> str:
        url_files = self.__get_url_files()
        update_res = self.__ask_to_update()

        if not update_res.lower() in ["y", "yes"]:
            if url_files:
                return url_files[0]
            else:
                click.secho(
                    "No URL(csv) file found. Please update the file first.\n",
                    fg="red",
                    bold=True,
                )
            return self._get_url_file()
        else:
            user_res = self.__add_or_update_url_file(url_files)
            url_files = self.__get_url_files()
            if not user_res.lower() in ["y", "yes"]:
                if not url_files:
                    click.secho(
                        "No URL(csv) file found. Please update the file first.\n",  # noqa
                        fg="red",
                        bold=True,
                    )
                    return self._get_url_file()
                return url_files[0]
            else:
                if url_files:
                    return url_files[0]
                else:
                    click.secho(
                        "No URL(csv) file found. Please update the file first.\n",  # noqa
                        fg="red",
                        bold=True,
                    )
                    return self._get_url_file()

    def _get_start_index(self) -> int:
        update_res = self.__ask_update_start()
        start_file = os.path.abspath(
            os.path.join(parent_dir, ".store", "start.txt")
        )
        with open(start_file, "r") as f:
            start_index = f.read().strip()

        if update_res.lower() in ["y", "yes"]:
            click.clear()
            start_index = click.prompt(
                click.style("Enter the start index: ", fg="blue", bold=True)
            )

            if not start_index.isdigit():
                click.secho(
                    "Invalid start index. Please enter a valid number.\n",
                    fg="red",
                )
                return self._get_start_index()

            with open(start_file, "w") as f:
                f.write(start_index.strip())

            click.echo()

            return int(start_index)

        return int(start_index)

    def _read_urls_from_csv(
        self, file_path: str, start: int
    ) -> Tuple[List[List[str]], int]:
        click.clear()
        urls = []
        with open(file_path, "r") as csv_file:
            reader = csv.reader(csv_file)
            rows = list(reader)
            s = start - 1
            e = s + 1000
            urls = rows[s:e]
            total_remaining_urls = len(rows[s:])
        click.secho(
            f"📃 Read {len(urls)} URLs from {file_path}.\n",
            fg="cyan",
            italic=True,
        )

        return urls, total_remaining_urls

    def _get_service_acounts(self) -> List[str]:
        json_files = [
            file
            for file in os.listdir(
                os.path.abspath(
                    os.path.join(parent_dir, ".store", ".services")
                )
            )
            if file.endswith(".json")
        ]
        if not json_files:
            json_files = []
            service_file = click.prompt(
                click.style(
                    "Drag and drop the service file(.json) here",
                    fg="magenta",
                    bold=True,
                )
            ).strip(string.whitespace + "'\"")
            service_file_path = pathlib.Path(service_file.strip()).resolve()

            if (
                service_file_path.is_file()
                and service_file_path.suffix == ".json"
                and service_file_path.exists()
            ):
                shutil.copy(
                    service_file_path,
                    os.path.abspath(
                        os.path.join(parent_dir, ".store", ".services")
                    ),
                )
                json_files.append(service_file_path.name)
                click.secho(
                    "\nIMPORTANT: Copy the following service account to your Search Console with owner's permission: \n",  # noqa
                    fg="red",
                    bold=True,
                )

                with open(service_file_path, "r") as f:
                    client_email = json.load(f)["client_email"]

                click.secho(client_email, fg="green", italic=True)
                click.confirm("\nPress Enter to continue")
            else:
                click.secho(
                    "Your program has not configured properly. Try again!\n",
                    fg="yellow",
                    bold=True,
                )
                return self._get_service_acounts()

        return json_files[:5]

    def _lets_gindex(
        self,
        url_file: str,
        start_index: int,
        file_name: str,
        service_acounts: List[str],
    ) -> Tuple[int, int, List[str], int]:
        urls_to_index, total_remaining = self._read_urls_from_csv(
            url_file, start_index
        )

        total_bars = min(len(service_acounts) * 200, len(urls_to_index))
        if urls_to_index:
            click.clear()
            click.secho(
                f"Sending indexing request for {total_bars} URLs from “{file_name}” file, starting from index {start_index}.\n",  # noqa
                fg="blue",
                italic=True,
            )
        s, e = 0, 200
        click.secho()
        with tqdm(
            total=total_bars,
            colour="blue",
            dynamic_ncols=True,
            unit="page",
            bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]",  # noqa
        ) as pbar:
            total_errors, total_success = 0, 0
            error_urls = []
            for auth_file in service_acounts:
                http = self.__authenticate(auth_file)
                urls = urls_to_index[s:e]

                if not urls:
                    break

                for url in urls:
                    content = {}
                    content["url"] = url[0].strip()
                    content["type"] = "URL_UPDATED"
                    json_content = json.dumps(content)

                    _, content = http.request(
                        self.ENDPOINT, method="POST", body=json_content
                    )

                    result = json.loads(content.decode())  # type: ignore

                    if "error" in result:
                        total_errors += 1
                        error_urls.append(url)

                        logs_directory = os.path.join(
                            parent_dir, ".store", "logs"
                        )

                        if os.path.exists(logs_directory):
                            os.rmdir(logs_directory)

                        os.makedirs(logs_directory)

                        current_date = datetime.now().strftime(
                            "%Y-%m-%d_%H-%M-%S"
                        )
                        log_file_name = os.path.join(
                            logs_directory, f"{current_date}_error_log.txt"
                        )

                        with open(log_file_name, "w") as log_file:
                            log_file.write(result)
                    else:
                        total_success += 1
                        time.sleep(0.25)
                    pbar.update(1)
                    pbar.set_description(
                        f"Indexing [Success: {total_success}, Error: {total_errors}]"  # noqa
                    )

                s, e = e, e + 200
            pbar.colour = "green"
            pbar.desc = "Indexing Completed"

            return total_success, total_errors, error_urls, total_remaining


def main(p_error: bool) -> Tuple[int, int, int, List[str]]:
    if p_error:
        log_file = os.path.abspath(os.path.join(parent_dir, ".store", "logs"))
        system_platform = platform.system()
        try:
            if system_platform == "Windows":
                os.startfile(log_file)
            elif system_platform == "Darwin":
                subprocess.Popen(["open", log_file])
            elif system_platform == "Linux":
                subprocess.Popen(["xdg-open", log_file])
        except Exception as e:
            click.secho("Unable to open the urls folder.", fg="red", bold=True)
            click.echo(f"Exception: {e}")
        click.secho("The logs folder has been opened.", fg="cyan", italic=True)
        click.secho(
            "Please send me the log files to troubleshoot the issue.\n",
            fg="cyan",
            italic=True,
        )
        sys.exit(0)
    try:
        gindexer = SetupGindex()
        service_acounts = gindexer._get_service_acounts()
        url_file = gindexer._get_url_file()
        start_index = gindexer._get_start_index()
        url_file_path = os.path.abspath(
            os.path.join(parent_dir, ".store", ".urls", url_file)
        )

        succ, err, err_urls, remaining = gindexer._lets_gindex(
            url_file_path, start_index, url_file, service_acounts
        )

        click.secho(
            "The program has completed indexing successfully.\n",
            fg="green",
            bold=True,
        )

    except KeyboardInterrupt:
        click.secho("\nExiting...\n", fg="red", italic=True)
        sys.exit(0)
    except click.exceptions.Abort:
        click.secho("\nExiting...\n", fg="red", italic=True)
        sys.exit(0)

    return succ, err, remaining, err_urls


if __name__ == "__main__":
    start_time = time.time()
    succ, err, remaining, err_urls = main(p_error=False)
    time_taken = time.time() - start_time
    hour = int(time_taken // 3600)
    minute = int((time_taken % 3600) // 60)
    second = int((time_taken % 3600) % 60)
    click.clear()
    _gbold("✔️ Indexing process completed successfully.\n")
    with Halo(
        text="Generating Summary...",
        spinner="dots",
        color="cyan",
        text_color="magenta",
    ) as spinner:
        time.sleep(2)
    click.echo(format_summary(succ, err, remaining, hour, minute, second))

    click.secho(
        "If you face any issues, please let me know at [mohammadnobinur[at]gmail[dot]com]",  # noqa
        fg="blue",
        italic=True,
    )
    click.secho("\n\nThanks for using gindeX!\n\n", fg="cyan", bold=True)
