Set-ExecutionPolicy Bypass -Scope Process -Force;

cd "$env:USERPROFILE\.g1k\gindex1k";

.\genv\Scripts\Activate.ps1;

python main.py