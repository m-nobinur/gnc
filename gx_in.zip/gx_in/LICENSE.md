# License Number: 000-GIN9-Dx54-EX92-S051

## GINDEX COMMERCIAL LICENSE

   Version 1.1.0

1. Definitions.

   a. "The Program" refers to the software application known as "gindex," including all related components, documentation, and updates.

   b. "You" or "Licensee" refers to any individual, entity, or organization obtaining a commercial license for the use of the Program.

2. Grant of License.

   Subject to the terms and conditions of this License, the Licensor hereby grants You a non-exclusive, non-transferable, worldwide license to use, modify, and distribute the Program for commercial purposes.

3. License Fee.

   In consideration for the rights granted under this License, You agree to pay the Licensor a one-time license fee in the amount of 58 USD within 2 days of the Effective Date.

4. License Number.

   You will be provided with a unique License Number upon payment of the license fee. This License Number must be referenced in all communications and correspondences related to this License.

5. Support and Maintenance.

   The Licensor may, at its discretion, provide support and maintenance services for the Program, subject to separate arrangements and fees, if applicable.

6. Term and Termination.

   This License shall be effective from the Effective Date and shall continue until terminated. Either party may terminate this License for breach by providing written notice with a 30-day cure period. Upon termination, You must cease using and distributing the Program.

7. Confidentiality.

   You agree to keep the Program and any related documentation confidential and shall not disclose, share, or distribute it to any third party without the prior written consent of the Licensor.

8. Warranty and Liability.

   The Program is provided "as is" without any warranties, expressed or implied. Licensor shall not be liable for any damages arising out of the use or inability to use the Program.

9. Governing Law.

   This License is governed by and construed in accordance with the laws of [Your Jurisdiction], excluding its conflict of laws principles.

10. Entire Agreement.

   This License constitutes the entire understanding between the parties concerning the Program and supersedes all prior agreements, whether oral or written.

IN WITNESS WHEREOF, the parties hereto have executed this Gindex Commercial License as of the Effective Date.

Developer:</br>
Name: M Nobinur</br>
Email: <info.mohammadnobinur@gmail.com>
