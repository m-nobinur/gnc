$ginFolder = "$env:USERPROFILE\._gindex"
cd "$ginFolder\gindex"
python main.py