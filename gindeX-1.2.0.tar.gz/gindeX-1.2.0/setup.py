from setuptools import setup, find_packages

setup(
    name="gindeX",
    version="1.2.0",
    author="M Nobinur",
    author_email="mohammadnobinur@gmail.com",
    description="A comprehensive command-line tool for submitting pages for indexing.",
    long_description="A CLI tool that allows users to submit pages for indexing on Google. The tool can be used to index up to 1000 pages at once.",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Commercial :: 000-GIN9-Dx54-EX92-S051",
        "Operating System :: OS Independent",
    ],
    install_requires=[
        "google-api-python-client==2.86.0",
        "google-auth-httplib2==0.1.0",
        "google-auth-oauthlib==1.0.0",
        "oauth2client==4.1.3",
        "pandas==2.1.3",
        "click==8.1.3",
        "halo==0.0.31",
        "beautifulsoup4==4.12.2",
        "lxml==4.9.3",
        "tqdm==4.66.1",
    ],
    entry_points={
        "console_scripts": [
            "gindexer = gindex.main:main",
        ],
    },
)
