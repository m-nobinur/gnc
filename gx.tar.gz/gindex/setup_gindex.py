#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import time
import click

from halo import Halo


def _action():
    click.clear()
    click.secho(
        "Running gindeX Installer...\n",
        fg="cyan",
        italic=True,
    )
    if os.path.basename(os.getcwd()) != "gindex":
        click.secho(
            "Please run this script from the gindex directory.",
            fg="yellow",
            bold=True,
        )
    else:
        with Halo(
            text="Setting up gindex...",
            spinner="dots",
            color="magenta",
            text_color="green",
        ) as spinner:
            dir_path = os.path.dirname(os.getcwd())
            dir_path = os.path.join(dir_path, "gindex")

            if os.path.exists(
                os.path.expanduser("~/._gindexer2")
            ) and os.path.isfile(os.path.expanduser("~/._gindexer2")):
                try:
                    os.remove(str(os.path.expanduser("~/._gindexer2")))
                except Exception:
                    subprocess.run(["sudo", "rm", "~/.gindexer2"])

            if not os.path.isdir(os.path.expanduser("~/._gindexer2")):
                os.makedirs(os.path.expanduser("~/._gindexer2"))
            else:
                shutil.rmtree(os.path.expanduser("~/._gindexer2"))
                os.makedirs(os.path.expanduser("~/._gindexer2"))
            shutil.copytree(
                dir_path, os.path.expanduser("~/._gindexer2/gindex")
            )
            os.chdir(os.path.expanduser("~/._gindexer2/gindex"))
            subprocess.run(
                ["python3", "-m", "venv", ".gindexer2_venv"],
                check=True,
                capture_output=True,
            )
            spinner.text = "Installing requirements (it may take a while)..."
            spinner.spinner = "dots12"
            spinner.color = "cyan"
            spinner.text_color = "blue"
            subprocess.run(
                [
                    ".gindexer2_venv/bin/python3",
                    "-m",
                    "pip",
                    "install",
                    "-r",
                    "requirements.txt",
                ],
                check=True,
                capture_output=True,
            )
            spinner.text = "Installing script..."
            spinner.color = "green"
            time.sleep(1)
            subprocess.run(
                ["chmod", "+x", "./gindexer2"], check=True, capture_output=True
            )
            shutil.copy("./gindexer2", "/usr/local/bin")
            spinner.succeed("Setup complete.")

        if os.path.isfile("/usr/local/bin/gindexe2r"):
            click.secho(
                "Congratulations! 'gindexer2' is now ready to use.\n",
                fg="green",
            )
        else:
            click.secho("Installation is partially failed.", fg="red")
            click.secho(
                "Please run the following command manually:\n",
                fg="cyan",
                bold=True,
            )
            click.secho(
                "\tchmod +x ~/._gindexer2/gindex/gindexer2",
                fg="blue",
                italic=True,
            )
            click.secho(
                "\tsudo cp ~/._gindexer2/gindex/gindexer2 /usr/local/bin",
                fg="blue",
                italic=True,
            )
            click.secho(
                "\n\nFinally, run 'gindexer2' to start using gindex.\n",
                fg="green",
            )
            sys.exit(1)

        click.echo("-" * 20)
        click.secho(
            f"\n\nRun {click.style('gindexer2', fg='blue', bold=True)} to start using gindex.",  # noqa
            fg="cyan",
            italic=True,
            bold=False,
        )
        click.echo(f"{'-' * 30}\n")


if __name__ == "__main__":
    _action()
