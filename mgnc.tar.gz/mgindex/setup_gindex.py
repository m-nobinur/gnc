#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import time
import click

from halo import Halo


def _action():
    click.clear()
    click.secho(
        "Running multi-gindeX Installer...\n",
        fg="cyan",
        italic=True,
    )
    if os.path.basename(os.getcwd()) != "mgindex":
        click.secho(
            "Please run this script from the multi-gindex directory.",
            fg="yellow",
            bold=True,
        )
    else:
        with Halo(
            text="Setting up multi-gindex...",
            spinner="dots",
            color="magenta",
            text_color="green",
        ) as spinner:
            dir_path = os.path.dirname(os.getcwd())
            dir_path = os.path.join(dir_path, "mgindex")

            if os.path.exists(
                os.path.expanduser("~/._mgindexer")
            ) and os.path.isfile(os.path.expanduser("~/._mgindexer")):
                try:
                    os.remove(str(os.path.expanduser("~/._mgindexer")))
                except Exception:
                    subprocess.run(["sudo", "rm", "~/.multigx"])

            if not os.path.isdir(os.path.expanduser("~/._mgindexer")):
                os.makedirs(os.path.expanduser("~/._mgindexer"))
            else:
                shutil.rmtree(os.path.expanduser("~/._mgindexer"))
                os.makedirs(os.path.expanduser("~/._mgindexer"))
            shutil.copytree(
                dir_path, os.path.expanduser("~/._mgindexer/mgindex")
            )
            os.chdir(os.path.expanduser("~/._mgindexer/mgindex"))
            subprocess.run(
                ["python3", "-m", "venv", ".mgindex_venv"],
                check=True,
                capture_output=True,
            )
            spinner.text = "Installing requirements (it may take a while)..."
            spinner.spinner = "dots12"
            spinner.color = "cyan"
            spinner.text_color = "blue"
            subprocess.run(
                [
                    ".mgindex_venv/bin/python3",
                    "-m",
                    "pip",
                    "install",
                    "-r",
                    "requirements.txt",
                ],
                check=True,
                capture_output=True,
            )
            spinner.text = "Installing script..."
            spinner.color = "green"
            time.sleep(1)
            subprocess.run(
                ["chmod", "+x", "./multigx"], check=True, capture_output=True
            )
            shutil.copy("./multigx", "/usr/local/bin")
            spinner.succeed("Setup complete.")

        if os.path.isfile("/usr/local/bin/multigx"):
            click.secho(
                "Congratulations! 'multi-gindexer' is now ready to use.\n",
                fg="green",
            )
        else:
            click.secho("Installation is partially failed.", fg="red")
            click.secho(
                "Please run the following command manually:\n",
                fg="cyan",
                bold=True,
            )
            click.secho(
                "\tchmod +x ~/._mgindexer/mgindex/multigx",
                fg="blue",
                italic=True,
            )
            click.secho(
                "\tsudo cp ~/._mgindexer/mgindex/multigx /usr/local/bin",
                fg="blue",
                italic=True,
            )
            click.secho(
                "\n\nFinally, run 'multigx' to start using multi-gindexer.\n",
                fg="green",
            )
            sys.exit(1)

        click.echo("-" * 20)
        click.secho(
            f"\n\nRun {click.style('multigx', fg='blue', bold=True)} to start using multi-gindexer.",  # noqa
            fg="cyan",
            italic=True,
            bold=False,
        )
        click.echo(f"{'-' * 30}\n")


if __name__ == "__main__":
    _action()
