import click


def bold(text: str) -> str:
    return click.style(text, bold=True)


def _cbold(text: str) -> str:
    return click.style(text, fg="bright_cyan", bold=True)


def _gbold(text: str) -> str:
    return click.style(text, fg="bright_green", bold=True)


def format_summary(
    total_success: int,
    total_errors: int,
    total_remaining_urls: int,
    hour: int,
    minute: int,
    second: int,
) -> str:
    return f"""

╭─────────────────────────────────────────────────╮
│            {_gbold("Indexing Process Summary")}              │
├───────────────────────────┬─────────────────────┤
│ {_cbold("Total indexing requests")}   │ {bold(f"{(total_errors + total_success):02d}")}                  │
├───────────────────────────┼─────────────────────┤
│ {_cbold("Total URLs indexed")}        │ {bold(f"{total_success:02d}")}                  │
├───────────────────────────┼─────────────────────┤
│ {_cbold("Total errors")}              │ {bold(f"{total_errors:02d}")}                  │
├───────────────────────────┼─────────────────────┤
│ {_cbold("Total URLs left")}           │ {bold(f"{(int(total_remaining_urls) - total_success - total_errors):03d}")}                 │
├───────────────────────────┼─────────────────────┤
│ {_cbold("Total time taken")}          │ {bold(f"{hour}H {minute:02d}M {second:2d} Seconds")}   │
╰─────────────────────────────────────────────────╯

"""
